import { Component, OnInit } from '@angular/core';
import { HostListener} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import {MylrService} from '../../mylr.service';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { AdvertisementDetail } from '../../pages/models/advertisement';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { add } from './../../pages/models/add'
import { Router } from '@angular/router';

@Component({
  selector: 'app-right-sidebar',
  templateUrl: './right-sidebar.component.html',
  styleUrls: ['./right-sidebar.component.css']
})
export class RightSidebarComponent implements OnInit {


  public showAd:any;
  public scroll:any;
  constructor(private newService: MylrService) {
    const headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
    this.newService.advertisementlist({}).subscribe(
      resultArray => {
        this.showAd = resultArray;
        this.showAd = this.showAd.response
        console.log( this.showAd);
      });
   }

  ngOnInit() {
    
}
// scroller() {
//    console.log("1")
//   this.scroll = $('div.scroll');// Sets the div with a class of scroll as a variable
//   var height = this.scroll.height(); // Gets the height of the this.scroll div
  
//   var topAdj = height="30px"; /* '-height' turns the height                   of the UL into a negative #, 
//                * '- 50' subtracts an extra 50 pixels from the height of 
//               * the div so that it moves the trail of the UL higher to 
//               * the top of the div before the animation                ends
//               */

//     this.scroll.animate({
//    'top' : [topAdj, 'linear'] 
//  }, 8000, function(){
//    this.scroll.css('top', 800); //resets the top position of the Ul for the next cycle
//     this.scroller(); // Recalls the animation cycle to begin.  
//   });
// }



}